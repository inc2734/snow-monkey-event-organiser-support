# Snow Monkey Event Organiser Support

With this plugin, Snow Monkey can use Event Organiser plugin.

## Build

```bash
$ npm install
$ composer install
```
